# WRR

Method: computable general equilibrium (CGE) modeling based on the regional Idaho-Washington CGE model, developed by Leroy Stodick, David Holland and Stephen Devadoss  (2002).


Software: General Algebraic Modeling System (GAMS; .gms) – mathematical programming and optimization.  

Two counties are analyzed in separate folders: Hamilton County, OH and New Hannover County, NC

In each Folder:
GAMS Files: check.gms; aggreg.gms; map.gms; model.gms  
Data Files: 26 data files (.dat)


 

1 In check.gms, set all program and data paths to correct files and folders. 

 

PROGPATH is the folder where the aggreg.gms and map.gms programs are located. It is also the folder where the SAM.gms file will be saved.  

 

$SETGLOBAL PROGPATH C:\GAMS\Cincinnati\ 

 

DATAPATH is the folder where the 26 data files are located. 

 

$SETGLOBAL DATAPATH C:\GAMS\Cincinnati\ 

 

DATANAM is the common suffix of the 26 data files. 

 

$SETGLOBAL DATANAM   

 

2/ Social accounting matrix (SAM) is a record of transactions and transfers between activities (A) and commodities (C) of industries, factors (F), and institutions (INST). 
 

3/ In check.gms, all activities, commodities, factors, and institutions are listed. According to 2018 IMPAN data, there are total 546 industries. Activity index ranges from 1 to 546 and commodity ranges from 3,001 to 3,545. 


4/ In map.gms, the 546 industries are allocated to 29 aggregated sectors.  

5/ aggreg.gms has codes to structure aggregated SAM as instructed in maps.gms. Set path to correct maps file name. 

 

$INCLUDE MAP_Cincinnati.gms 
